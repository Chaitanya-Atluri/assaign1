import "./App.css";
import ItemsContextProvider from "./Store/items-context";
import Product from './components/Items';
function App() {
  

  return (
    <ItemsContextProvider>
      <Product/>
     </ItemsContextProvider>
  );
}

export default App;
