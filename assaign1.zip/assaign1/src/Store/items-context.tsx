import Items from "../Models/Items";
import React,{useState,useEffect} from 'react';
const tempItems :Items[] =[
  {
      "catogery": "dessert",
      "name": "gulab jamun",
      "calories": "200",
      "fat": "25",
      "carbs": "67",
      "protiens": "12",
      "id": "a12bh"
  },
  {
      "catogery": "dessert",
      "name": "ice cream",
      "calories": "150",
      "fat": "26",
      "carbs": "87",
      "protiens": "12",
      "id": "aibhy"
  },
  {
      "catogery": "drink",
      "name": "coco-cola",
      "calories": "100",
      "fat": "12",
      "carbs": "23",
      "protiens": "1",
      "id": "ni8ju"
  },
  {
      "catogery": "drink",
      "name": "sprite",
      "calories": "96",
      "fat": "10",
      "carbs": "25",
      "protiens": "2",
      "id": "nj97u"
  },
  {
      "catogery": "rice",
      "name": "chicken biryani",
      "calories": "85",
      "fat": "23",
      "carbs": "77",
      "protiens": "10",
      "id": "mk8rd"
  },
  {
      "catogery": "rice",
      "name": "mutton biryani",
      "calories": "95",
      "fat": "34",
      "carbs": "57",
      "protiens": "12",
      "id": "njik6"
  },
  {
      "catogery": "starters",
      "name": "chicken 65",
      "calories": "66",
      "fat": "25",
      "carbs": "62",
      "protiens": "24",
      "id": "d65rg"
  },
  {
      "catogery": "starters",
      "name": "onion pakodi",
      "calories": "54",
      "fat": "28",
      "carbs": "61",
      "protiens": "31",
      "id": "a3ef6"
  }
];
type itemContext={
    products: Items[];
    removeItem: (selected: string[]) => void;
  };

export const ItemsContext = React.createContext<itemContext>({
  products: [],
  removeItem: (selected: string[]) => {},
});

const ItemsContextProvider: React.FC = (props) => {
  const[items,setItems]=useState<Items[]>([]);
  useEffect(()=>{
    setItems(tempItems);
  },[])
  
  const removeHandler =(selected:string[]) => {
    selected.map((id)=>{
      setItems((prev)=>{
        return prev.filter(todo =>todo.id !== id);
      })
      console.log(id);
    });
  };

  const contextValue : itemContext = ({
    products : items,
    removeItem: removeHandler
  });
  return <ItemsContext.Provider value={contextValue}>{props.children}</ItemsContext.Provider>;
};

export default ItemsContextProvider;